<template>
  <div>
    <h1>About Page</h1>
    <p>This is About page</p>
  </div>
</template>
