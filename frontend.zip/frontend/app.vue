<template>
    <div>
        <NuxtLayout>
            <NuxtPage />
        </NuxtLayout>
        <ToastWrapper />
    </div>
</template>

<script setup>
import ToastWrapper from '~/components/ToastWrapper.vue';
</script>